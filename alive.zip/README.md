# Suscribe to Atreya YT
- [Subscribe](https://www.youtube.com/channel/UCprRYOr1nWjKDklvvBIqw5g/videos)
# Music Bot with filter
Best music bot with all filters, queue, and other cool features

## This bot was made Atreya YT#0700, do not remove credits or you will have copyright issues.
### Make sure to join The servers below:
- [Capital Club](https://discord.gg/gU7XAxTpX5)

#### Star the repo and fork it, Ty
###### Things You should not do
- Dont remove credits
- Dont say u created it when u didnt
- dont copy paste or u will never learn
##### Things you should to do:
- Suscribe to Atreya YT
- star this repo
- fork this repo
- follow me
- make videos on my projects
- Gift me nitro for more code
- join recluse community


##### Modification 
- Add you token in `config.json`
- Add your prefix in `config.json`
- run it by `node index.js` 
- Add your YOUTUBE_API_KEY 
You can get from 
[Here](https://media.discordapp.net/attachments/766714025412395058/850607366390284308/unknown.png)


Please Subscribe to my channel and for help join my server.